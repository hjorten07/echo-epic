import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { StarRating } from "@/components/StarRating";
import { CommunityRatingBreakdown } from "@/components/CommunityRatingBreakdown";
import { useAuth } from "@/hooks/useAuth";
import { useUserRating, useItemRating, useRateMutation, useDeleteRatingMutation } from "@/hooks/useRatings";
import { useCheckAndAwardBadges, useUpdateStreak } from "@/hooks/useBadges";
import { Trash2, Plus, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { AddToPlaylistDialog } from "@/components/AddToPlaylistDialog";
import { ShareMusicDialog } from "@/components/ShareMusicDialog";

interface ItemRatingSectionProps {
  itemType: "artist" | "album" | "song";
  itemId: string;
  itemName: string;
  itemImage?: string;
  itemSubtitle?: string;
}

export const ItemRatingSection = ({
  itemType,
  itemId,
  itemName,
  itemImage,
  itemSubtitle,
}: ItemRatingSectionProps) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [showPlaylistDialog, setShowPlaylistDialog] = useState(false);
  const [showShareDialog, setShowShareDialog] = useState(false);
  
  const { data: userRating } = useUserRating(itemType, itemId);
  const { data: itemRating } = useItemRating(itemType, itemId);
  const rateMutation = useRateMutation();
  const deleteMutation = useDeleteRatingMutation();
  const checkBadges = useCheckAndAwardBadges();
  const updateStreak = useUpdateStreak();

  const handleRate = async (rating: number) => {
    if (!user) {
      toast.info("Please log in to rate");
      navigate("/auth");
      return;
    }

    try {
      await rateMutation.mutateAsync({
        itemType,
        itemId,
        itemName,
        itemImage,
        itemSubtitle,
        rating,
      });
      toast.success(`Rated ${itemName} ${rating}/10!`);
      
      // Check for new badges and update streak
      await Promise.all([
        checkBadges.mutateAsync(),
        updateStreak.mutateAsync(),
      ]);
    } catch (error) {
      toast.error("Failed to save rating");
    }
  };

  const handleDeleteRating = async () => {
    if (!userRating?.id) return;
    
    try {
      await deleteMutation.mutateAsync(userRating.id);
      toast.success("Rating deleted");
    } catch (error) {
      toast.error("Failed to delete rating");
    }
  };

  const avgRating = itemRating?.avg_rating || 0;
  const totalRatings = itemRating?.total_ratings || 0;
  const currentUserRating = userRating?.rating || 0;

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-6">
        {/* User Rating - Interactive Stars */}
        <div className="flex-1">
          <p className="text-sm text-muted-foreground mb-2">
            {user ? "Your Rating" : "Rate This"}
          </p>
          <div className="flex items-center gap-3">
            <StarRating
              rating={currentUserRating}
              onRate={handleRate}
              size="lg"
              showValue={currentUserRating > 0}
            />
            {user && currentUserRating > 0 && (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleDeleteRating}
                className="text-destructive hover:text-destructive shrink-0"
                title="Delete rating"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
          </div>
          {!user && (
            <p className="text-xs text-muted-foreground mt-2">
              <button
                onClick={() => navigate("/auth")}
                className="text-primary hover:underline"
              >
                Log in
              </button>
              {" "}to rate this {itemType}
            </p>
          )}
          {user && currentUserRating === 0 && (
            <p className="text-xs text-muted-foreground mt-2">
              Click a star to rate
            </p>
          )}
        </div>

        {/* Community Rating - with dropdown breakdown */}
        <CommunityRatingBreakdown
          itemType={itemType}
          itemId={itemId}
          avgRating={avgRating}
          totalRatings={totalRatings}
        />
      </div>

      {/* Action Buttons */}
      {user && (
        <div className="flex gap-2 flex-wrap">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setShowPlaylistDialog(true)}
            className="gap-2"
          >
            <Plus className="w-4 h-4" />
            Add to Playlist
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setShowShareDialog(true)}
            className="gap-2"
          >
            <Share2 className="w-4 h-4" />
            Share
          </Button>
        </div>
      )}

      {/* Dialogs */}
      <AddToPlaylistDialog
        open={showPlaylistDialog}
        onOpenChange={setShowPlaylistDialog}
        songId={itemId}
        songName={itemName}
        songArtist={itemSubtitle}
        songImage={itemImage}
      />
      <ShareMusicDialog
        open={showShareDialog}
        onOpenChange={setShowShareDialog}
        itemType={itemType}
        itemId={itemId}
        itemName={itemName}
        itemImage={itemImage}
        itemArtist={itemSubtitle}
      />
    </div>
  );
};
